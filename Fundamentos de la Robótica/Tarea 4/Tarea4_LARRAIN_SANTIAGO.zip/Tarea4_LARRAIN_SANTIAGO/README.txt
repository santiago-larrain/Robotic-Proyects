Pregunta 1:
	- Se explica brevemente el termostato y se muestra su diagrama de flujo
	- Se describe en forma simple el control crucero automático y se muestra un diagrama de flujo encontrado en internet. 
Pregunta 2:
	- En su carpeta, se encuentran los archivos PDF para las preguntas 2.1 y 2.2
	  y para las preguntas 2.3 y 2.4 se encuentras los códigos .py comentados
	  y en los respectivos PDF (..._Analisis.pdf) Se hacen los análisis pedidos.
	- En el código .py de la pregunta 2.4 se requiere una entrada de usuario para
	  elegir el controlador. Los parámetros se eligieron para encontrar buenas funciones
	  y sobre el controlador Bang-Bang, se define un Tau_On para cuando este se enciende.